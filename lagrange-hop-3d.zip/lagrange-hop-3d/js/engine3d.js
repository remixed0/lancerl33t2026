/*
 * Lagrange Hop 3D — tiny 3D engine on a 2D canvas
 *
 * An orbit camera, perspective projection, mouse picking on the orbital
 * plane, and a flat-shaded mesh renderer (painter's algorithm).
 * No libraries, so the game runs offline from a single folder.
 */
(function (root) {
  'use strict';

  const v3 = {
    add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }),
    sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }),
    scale: (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s }),
    dot: (a, b) => a.x * b.x + a.y * b.y + a.z * b.z,
    cross: (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }),
    len: (a) => Math.hypot(a.x, a.y, a.z),
    norm: (a) => { const l = Math.hypot(a.x, a.y, a.z) || 1; return { x: a.x / l, y: a.y / l, z: a.z / l }; }
  };

  // ---------------- Camera ----------------
  function Camera() {
    this.target = { x: 0, y: 0, z: 2 };
    this.yaw = 0;            // rotation around the vertical axis
    this.pitch = 0.92;       // angle above the orbital plane (radians)
    this.dist = 80;
    this.fov = 50 * Math.PI / 180;
    // Smoothed values (the camera eases toward its goal)
    this.goal = { yaw: this.yaw, pitch: this.pitch, dist: this.dist, tx: 0, tz: 2 };
    this.w = 1; this.h = 1;
    this.update(1);
  }

  Camera.prototype.setViewport = function (w, h) {
    this.w = w; this.h = h;
    this.focal = (h / 2) / Math.tan(this.fov / 2);
  };

  /** Ease toward the goal and rebuild the basis vectors. */
  Camera.prototype.update = function (ease) {
    const g = this.goal;
    const k = ease === undefined ? 0.15 : ease;
    let dy = g.yaw - this.yaw;
    dy = Math.atan2(Math.sin(dy), Math.cos(dy));
    this.yaw += dy * k;
    this.pitch += (g.pitch - this.pitch) * k;
    this.dist += (g.dist - this.dist) * k;
    this.target.x += (g.tx - this.target.x) * k;
    this.target.z += (g.tz - this.target.z) * k;

    const cp = Math.cos(this.pitch);
    this.pos = {
      x: this.target.x + this.dist * cp * Math.sin(this.yaw),
      y: this.target.y + this.dist * Math.sin(this.pitch),
      z: this.target.z + this.dist * cp * Math.cos(this.yaw)
    };
    this.fwd = v3.norm(v3.sub(this.target, this.pos));
    // Near top-down, derive "right" from yaw so the view never flips.
    this.right = { x: Math.cos(this.yaw), y: 0, z: -Math.sin(this.yaw) };
    this.up = v3.norm(v3.cross(this.right, this.fwd));
  };

  /** World point -> screen. Returns null when behind the camera. */
  Camera.prototype.project = function (p) {
    const dx = p.x - this.pos.x, dy = p.y - this.pos.y, dz = p.z - this.pos.z;
    const zc = dx * this.fwd.x + dy * this.fwd.y + dz * this.fwd.z;
    if (zc < 0.5) return null;
    const xc = dx * this.right.x + dy * this.right.y + dz * this.right.z;
    const yc = dx * this.up.x + dy * this.up.y + dz * this.up.z;
    const s = this.focal / zc;
    return { x: this.w / 2 + xc * s, y: this.h / 2 - yc * s, depth: zc, scale: s };
  };

  /** Screen point -> point on the orbital plane (y = 0), or null. */
  Camera.prototype.pickPlane = function (sx, sy) {
    const nx = (sx - this.w / 2) / this.focal;
    const ny = -(sy - this.h / 2) / this.focal;
    const dir = v3.norm({
      x: this.fwd.x + this.right.x * nx + this.up.x * ny,
      y: this.fwd.y + this.right.y * nx + this.up.y * ny,
      z: this.fwd.z + this.right.z * nx + this.up.z * ny
    });
    if (Math.abs(dir.y) < 1e-4) return null;
    const t = -this.pos.y / dir.y;
    if (t < 0) return null;
    return { x: this.pos.x + dir.x * t, y: 0, z: this.pos.z + dir.z * t };
  };

  /** Pick a distance so the whole play area fits the screen. */
  Camera.prototype.fitDistance = function (halfWidth, halfDepth) {
    const aspect = this.w / this.h;
    const t = Math.tan(this.fov / 2);
    const byWidth = halfWidth / (t * aspect);
    const byDepth = (halfDepth * Math.max(0.55, Math.sin(this.goal.pitch))) / t;
    return Math.max(byWidth, byDepth) * 1.08;
  };

  // ---------------- Meshes ----------------
  function Mesh(vertices, faces) {
    this.v = vertices;   // [{x,y,z}]
    this.f = faces;      // [{i:[a,b,c,...], color:[r,g,b], emissive:0..1}]
  }

  /** Icosahedron, optionally jittered into a lumpy asteroid. */
  Mesh.asteroid = function (radius, seed, color) {
    const t = (1 + Math.sqrt(5)) / 2;
    const raw = [
      [-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0],
      [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t],
      [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]
    ];
    let s = seed * 9301 + 49297;
    const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    const verts = raw.map(([x, y, z]) => {
      const l = Math.hypot(x, y, z);
      const k = radius * (0.78 + rnd() * 0.42) / l;
      return { x: x * k, y: y * k * 0.85, z: z * k };
    });
    const idx = [
      [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
      [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
      [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
      [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]
    ];
    const faces = idx.map((i) => ({ i, color: color || [130, 118, 108], emissive: 0 }));
    return new Mesh(verts, faces);
  };

  /** Octahedron crystal for science beacons. */
  Mesh.crystal = function (r, color) {
    const v = [
      { x: 0, y: r * 1.4, z: 0 }, { x: 0, y: -r * 1.4, z: 0 },
      { x: r, y: 0, z: 0 }, { x: -r, y: 0, z: 0 }, { x: 0, y: 0, z: r }, { x: 0, y: 0, z: -r }
    ];
    const idx = [[0, 4, 2], [0, 2, 5], [0, 5, 3], [0, 3, 4], [1, 2, 4], [1, 5, 2], [1, 3, 5], [1, 4, 3]];
    return new Mesh(v, idx.map((i) => ({ i, color, emissive: 0.55 })));
  };

  function box(cx, cy, cz, sx, sy, sz, color, emissive, verts, faces) {
    const b = verts.length;
    for (let i = 0; i < 8; i++) {
      verts.push({
        x: cx + (i & 1 ? sx : -sx),
        y: cy + (i & 2 ? sy : -sy),
        z: cz + (i & 4 ? sz : -sz)
      });
    }
    const q = [[0, 2, 3, 1], [4, 5, 7, 6], [0, 1, 5, 4], [2, 6, 7, 3], [0, 4, 6, 2], [1, 3, 7, 5]];
    q.forEach((f) => faces.push({ i: f.map((k) => b + k), color, emissive: emissive || 0 }));
  }

  /** Space probe: gold body, two long blue solar panels, a white dish. Faces +x. */
  Mesh.probe = function () {
    const v = [], f = [];
    box(0, 0, 0, 0.42, 0.3, 0.3, [222, 178, 80], 0.15, v, f);           // body (gold foil)
    box(0, 0, 1.15, 0.22, 0.04, 0.75, [40, 110, 220], 0.25, v, f);      // panel left
    box(0, 0, -1.15, 0.22, 0.04, 0.75, [40, 110, 220], 0.25, v, f);     // panel right
    box(0.55, 0, 0, 0.12, 0.34, 0.34, [235, 240, 248], 0.2, v, f);      // dish
    box(-0.5, 0, 0, 0.1, 0.12, 0.12, [255, 140, 60], 0.9, v, f);        // engine glow
    return new Mesh(v, f);
  };

  /** Orbital station: ring of panels around a core. */
  Mesh.station = function (color) {
    const v = [], f = [];
    box(0, 0, 0, 0.55, 0.55, 0.55, [220, 228, 236], 0.2, v, f);
    box(1.6, 0, 0, 0.9, 0.04, 0.4, [40, 110, 220], 0.3, v, f);
    box(-1.6, 0, 0, 0.9, 0.04, 0.4, [40, 110, 220], 0.3, v, f);
    box(0, 0, 1.4, 0.18, 0.18, 0.8, [200, 210, 220], 0.1, v, f);
    box(0, 0.9, 0, 0.12, 0.35, 0.12, color || [52, 211, 153], 0.9, v, f); // beacon light
    return new Mesh(v, f);
  };

  /**
   * Transform a mesh and collect its visible faces into `out` for sorting.
   * rot: { yaw, pitch, roll } in radians. scale: number.
   */
  function collectFaces(mesh, pos, rot, scale, cam, sun, out) {
    const cy = Math.cos(rot.yaw || 0), sy = Math.sin(rot.yaw || 0);
    const cx = Math.cos(rot.pitch || 0), sx = Math.sin(rot.pitch || 0);
    const cr = Math.cos(rot.roll || 0), sr = Math.sin(rot.roll || 0);
    const world = mesh.v.map((p) => {
      // roll (about x), pitch (about z), yaw (about y)
      let x = p.x * scale, y = p.y * scale, z = p.z * scale;
      let y1 = y * cr - z * sr, z1 = y * sr + z * cr; y = y1; z = z1;
      let x1 = x * cx - y * sx; y1 = x * sx + y * cx; x = x1; y = y1;
      x1 = x * cy + z * sy; z1 = -x * sy + z * cy; x = x1; z = z1;
      return { x: x + pos.x, y: y + pos.y, z: z + pos.z };
    });
    const proj = world.map((p) => cam.project(p));
    for (let n = 0; n < mesh.f.length; n++) {
      const face = mesh.f[n];
      const ids = face.i;
      let ok = true;
      for (let k = 0; k < ids.length; k++) if (!proj[ids[k]]) { ok = false; break; }
      if (!ok) continue;
      const a = world[ids[0]], b = world[ids[1]], c = world[ids[2]];
      const nrm = v3.norm(v3.cross(v3.sub(b, a), v3.sub(c, a)));
      const toCam = v3.sub(cam.pos, a);
      if (v3.dot(nrm, toCam) <= 0) continue; // back face
      let depth = 0;
      for (let k = 0; k < ids.length; k++) depth += proj[ids[k]].depth;
      depth /= ids.length;
      const diffuse = Math.max(0, v3.dot(nrm, sun));
      const light = Math.min(1.35, 0.22 + diffuse * 0.85 + face.emissive);
      out.push({
        depth,
        pts: ids.map((k) => proj[k]),
        fill: `rgb(${Math.min(255, face.color[0] * light) | 0},${Math.min(255, face.color[1] * light) | 0},${Math.min(255, face.color[2] * light) | 0})`
      });
    }
  }

  function drawFaces(ctx, faces) {
    faces.sort((p, q) => q.depth - p.depth);
    for (let n = 0; n < faces.length; n++) {
      const f = faces[n];
      ctx.beginPath();
      ctx.moveTo(f.pts[0].x, f.pts[0].y);
      for (let k = 1; k < f.pts.length; k++) ctx.lineTo(f.pts[k].x, f.pts[k].y);
      ctx.closePath();
      ctx.fillStyle = f.fill;
      ctx.fill();
      ctx.strokeStyle = f.fill;
      ctx.lineWidth = 0.6;
      ctx.stroke();
    }
  }

  // ---------------- Glow sprites ----------------
  const glowCache = {};
  /** A soft radial glow image for a given rgb, drawn with additive blending. */
  function glow(r, g, b) {
    const key = r + ',' + g + ',' + b;
    if (glowCache[key]) return glowCache[key];
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const x = c.getContext('2d');
    const grad = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, `rgba(${r},${g},${b},1)`);
    grad.addColorStop(0.25, `rgba(${r},${g},${b},0.55)`);
    grad.addColorStop(0.6, `rgba(${r},${g},${b},0.12)`);
    grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
    x.fillStyle = grad;
    x.fillRect(0, 0, 64, 64);
    glowCache[key] = c;
    return c;
  }

  root.LH3D = { v3, Camera, Mesh, collectFaces, drawFaces, glow };
})(window);
