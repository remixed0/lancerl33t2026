/*
 * Lagrange Hop 3D — mission definitions
 *
 * World units: x runs left to right (about -55 to 55 on screen),
 * z runs far to near (about -38 to 38). The orbital plane is y = 0.
 *
 * orbit: { cx, cz, r, period (s), phase (rad) } makes a body circle a point.
 * fuelGoal: fuel % needed (with every beacon) for 3 stars.
 * autopilot: a known 3-star launch (time in the orbit cycle, angle in
 *   degrees, speed). Press A in the game to watch it fly.
 * Run `node tools/check-levels.js` after editing to prove each mission
 * can still be beaten with 3 stars.
 */
(function (root) {
  'use strict';

  const LEVELS = [
    {
      title: 'MISSION 01: LUNAR SLINGSHOT',
      hint: 'Drag back from Earth and release. Swing past the Moon for a free speed boost.',
      predictTime: 12,
      missionTime: 12,
      fuelGoal: 66,
      autopilot: { t0: 10.75, deg: 330, speed: 7.375 },
      earth: { name: 'Earth', x: -36, z: 4, radius: 2.8, mass: 120, texture: 'earth' },
      bodies: [
        {
          name: 'Moon', radius: 1.6, mass: 75, texture: 'moon',
          orbit: { cx: -36, cz: 4, r: 16, period: 15, phase: 0 }
        }
      ],
      target: { name: 'Deep Space Relay', kind: 'station', x: 36, z: -14, captureRadius: 4.5, maxSpeed: 16 },
      beacons: [
        { x: -19.5, z: -7.5 },
        { x: -2.4, z: -9.5 },
        { x: 14.8, z: -10.7 }
      ],
      hazards: []
    },
    {
      title: 'MISSION 02: MARS INSERTION',
      hint: 'Thread the asteroid field. Arrive slow enough for Mars to catch you.',
      predictTime: 12,
      missionTime: 12,
      fuelGoal: 58,
      autopilot: { t0: 11.5, deg: 343.5, speed: 9.25 },
      earth: { name: 'Earth', x: -36, z: 13, radius: 2.8, mass: 120, texture: 'earth' },
      bodies: [
        { name: 'Mars', x: 32, z: -10, radius: 2.3, mass: 70, texture: 'mars' }
      ],
      target: { name: 'Mars Orbit', kind: 'planet', x: 32, z: -10, captureRadius: 6.5, maxSpeed: 15 },
      beacons: [
        { x: -17.8, z: 7.6 },
        { x: -2.9, z: 3.2 },
        { x: 12, z: -1.3 }
      ],
      hazards: [
        { name: 'Debris A', x: -6, z: 12, radius: 1.7 },
        { name: 'Debris B', x: -2, z: -3, radius: 1.9 },
        { name: 'Debris C', x: 4, z: -16, radius: 1.6 },
        { name: 'Ceres Fragment', x: 18, z: -22, radius: 1.4 },
        { name: 'Debris D', x: 14, z: 8, radius: 1.5 },
        {
          name: 'Drifting Rock', radius: 1.4,
          orbit: { cx: 10, cz: -4, r: 7, period: 12, phase: 1 }
        }
      ]
    },
    {
      title: 'MISSION 03: THE GRAND TOUR',
      hint: 'Jupiter bends everything. Ride Ganymede to reach Europa Base.',
      predictTime: 8,
      missionTime: 14,
      fuelGoal: 65,
      autopilot: { t0: 1.25, deg: 330, speed: 8.625 },
      earth: { name: 'Earth', x: -42, z: 2, radius: 2.6, mass: 110, texture: 'earth' },
      bodies: [
        { name: 'Jupiter', x: -2, z: 0, radius: 4.4, mass: 650, texture: 'jupiter' },
        {
          name: 'Ganymede', radius: 1.3, mass: 40, texture: 'ganymede',
          orbit: { cx: -2, cz: 0, r: 13, period: 14, phase: 1.5 }
        }
      ],
      target: { name: 'Europa Base', kind: 'station', x: 38, z: 2, captureRadius: 4.5, maxSpeed: 18 },
      beacons: [
        { x: -25.2, z: -6.2 },
        { x: -9.9, z: -8.4 },
        { x: 5.3, z: -9.9 },
        { x: 20, z: -5.3 }
      ],
      hazards: [
        { name: 'Radiation Belt', x: 16, z: 6, radius: 1.3 },
        { name: 'Space Junk', x: -24, z: 16, radius: 1.5 }
      ]
    }
  ];

  root.LHLevels = LEVELS;
  if (typeof module !== 'undefined' && module.exports) module.exports = LEVELS;
})(typeof window !== 'undefined' ? window : globalThis);
