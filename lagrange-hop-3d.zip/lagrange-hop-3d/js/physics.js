/*
 * Lagrange Hop 3D — physics engine
 *
 * The game plays out on a flat orbital plane (x, z). Gravity is a simple
 * N-body approximation: every planet/moon pulls the probe with a = m / r^2.
 * Moons move on circular orbits, so the trajectory prediction integrates the
 * SAME equations with the bodies' future positions. That is why the predicted
 * path matches the real flight exactly, and why real gravity assists
 * (stealing speed from a moving moon) work.
 *
 * This file has no browser dependencies, so the level checker
 * (tools/check-levels.js) can run it in Node.
 */
(function (root) {
  'use strict';

  const DT = 1 / 120;            // fixed physics step (seconds)
  const MAX_SPEED = 26;          // max launch speed (world units / s)
  const MIN_LAUNCH_SPEED = 2;    // ignore tiny accidental drags
  const PROBE_RADIUS = 0.45;
  const BEACON_RADIUS = 1.3;
  const BOUNDS = { x: 66, z: 46 };
  const MAX_FLIGHT_TIME = 40;    // default mission clock (levels can set missionTime)
  const KM_PER_UNIT = 1.5;       // display scale: world speed -> km/s (7.4 -> 11 km/s)
  const ASSIST_ZONE = 7;         // gravity-assist zone, in body radii

  /** Position of a body (planet, moon, hazard) at absolute time t. */
  function bodyPos(body, t) {
    const o = body.orbit;
    if (!o) return { x: body.x, z: body.z };
    const a = o.phase + (2 * Math.PI * t) / o.period;
    return { x: o.cx + Math.cos(a) * o.r, z: o.cz + Math.sin(a) * o.r };
  }

  /** All bodies that pull on the probe. */
  function attractors(level) {
    return [level.earth].concat(level.bodies);
  }

  /** Gravitational acceleration at (x, z) at time t. */
  function accelAt(level, x, z, t) {
    let ax = 0;
    let az = 0;
    let nearest = null;
    let nearestDist = Infinity;
    const list = attractors(level);
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      const p = bodyPos(b, t);
      const dx = p.x - x;
      const dz = p.z - z;
      const d2 = dx * dx + dz * dz;
      const d = Math.sqrt(d2) || 1e-6;
      // Softening stops the force from exploding at the center.
      const f = b.mass / Math.max(d2, b.radius * b.radius * 0.8);
      ax += (dx / d) * f;
      az += (dz / d) * f;
      if (b !== level.earth && d - b.radius < nearestDist) {
        nearestDist = d - b.radius;
        nearest = b;
      }
    }
    return { ax, az, nearest, nearestDist };
  }

  /** Initial state for a launch from Earth's surface. */
  function launchState(level, angle, speed, t0) {
    const e = level.earth;
    const dx = Math.cos(angle);
    const dz = Math.sin(angle);
    return {
      x: e.x + dx * (e.radius + 0.6),
      z: e.z + dz * (e.radius + 0.6),
      vx: dx * speed,
      vz: dz * speed,
      t: t0,
      t0: t0,
      launchSpeed: speed,
      collected: level.beacons.map(() => false),
      maxBoost: 1,
      zoneEntry: {},
      lastAssist: null,
      tooFast: false
    };
  }

  /** Advance one fixed physics step (semi-implicit Euler). */
  function step(level, s) {
    const g = accelAt(level, s.x, s.z, s.t);
    s.vx += g.ax * DT;
    s.vz += g.az * DT;
    s.x += s.vx * DT;
    s.z += s.vz * DT;
    s.t += DT;
    trackAssists(level, s);
    return g;
  }

  /**
   * Gravity assist gain = speed leaving a body's zone / speed entering it.
   * A still planet gives about 1.0x (what you gain falling in, you lose
   * climbing out). A moving moon can give more than 1.0x: a real slingshot.
   */
  function trackAssists(level, s) {
    const speed = Math.hypot(s.vx, s.vz);
    for (let i = 0; i < level.bodies.length; i++) {
      const b = level.bodies[i];
      const p = bodyPos(b, s.t);
      const inside = Math.hypot(s.x - p.x, s.z - p.z) < b.radius * ASSIST_ZONE;
      const entry = s.zoneEntry[i];
      if (inside && entry === undefined) {
        s.zoneEntry[i] = speed;
      } else if (!inside && entry !== undefined) {
        const ratio = speed / Math.max(entry, 0.001);
        if (ratio > s.maxBoost) s.maxBoost = ratio;
        s.lastAssist = { body: b.name, ratio };
        delete s.zoneEntry[i];
      }
    }
  }

  /**
   * Check what happened after a step.
   * Returns null while flying, or { type: 'capture' | 'crash' | 'lost', reason }.
   * Also returns newly collected beacon indexes in `beacons`.
   */
  function checkEvents(level, s) {
    const result = { end: null, beacons: [] };
    const speed = Math.hypot(s.vx, s.vz);

    // Science beacons
    for (let i = 0; i < level.beacons.length; i++) {
      if (s.collected[i]) continue;
      const b = level.beacons[i];
      if (Math.hypot(s.x - b.x, s.z - b.z) <= BEACON_RADIUS + PROBE_RADIUS) {
        s.collected[i] = true;
        result.beacons.push(i);
      }
    }

    // Orbital capture at the target
    const tg = level.target;
    const dTarget = Math.hypot(s.x - tg.x, s.z - tg.z);
    if (dTarget <= tg.captureRadius) {
      if (speed <= tg.maxSpeed) {
        result.end = { type: 'capture', reason: 'Captured into orbit at ' + tg.name + '.' };
        return result;
      }
      s.tooFast = true;
    }

    // Planet and moon impacts
    const list = attractors(level);
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      const p = bodyPos(b, s.t);
      if (Math.hypot(s.x - p.x, s.z - p.z) <= b.radius + PROBE_RADIUS * 0.5) {
        result.end = { type: 'crash', reason: 'Impact on ' + b.name + '.' };
        return result;
      }
    }

    // Asteroids and debris
    for (let i = 0; i < level.hazards.length; i++) {
      const h = level.hazards[i];
      const p = bodyPos(h, s.t);
      if (Math.hypot(s.x - p.x, s.z - p.z) <= h.radius + PROBE_RADIUS) {
        result.end = { type: 'crash', reason: 'Hit ' + h.name + '.' };
        return result;
      }
    }

    if (Math.abs(s.x) > BOUNDS.x || Math.abs(s.z) > BOUNDS.z) {
      result.end = { type: 'lost', reason: 'Drifted into deep space.' };
    } else if (s.t - s.t0 > missionTime(level)) {
      result.end = { type: 'lost', reason: 'Battery died before arrival. Fly faster or use a slingshot.' };
    }
    return result;
  }

  function missionTime(level) {
    return level.missionTime || MAX_FLIGHT_TIME;
  }

  /**
   * Run a whole flight. Used by the trajectory preview and the level checker.
   * opts.maxTime limits how far ahead to look; opts.every records a point
   * every N steps.
   */
  function simulate(level, angle, speed, t0, opts) {
    opts = opts || {};
    const maxTime = Math.min(opts.maxTime || Infinity, missionTime(level) + DT * 2);
    const every = opts.every || 0;
    const s = launchState(level, angle, speed, t0);
    const points = every ? [{ x: s.x, z: s.z }] : null;
    let end = null;
    let n = 0;
    while (s.t - t0 < maxTime) {
      step(level, s);
      const ev = checkEvents(level, s);
      n++;
      if (points && n % every === 0) points.push({ x: s.x, z: s.z });
      if (ev.end) {
        end = ev.end;
        break;
      }
    }
    if (points) points.push({ x: s.x, z: s.z });
    return {
      end: end || { type: 'open', reason: '' },
      points,
      state: s,
      beaconCount: s.collected.filter(Boolean).length
    };
  }

  /** Fuel left (percent) for a given launch speed. */
  function fuelLeft(speed) {
    return Math.max(0, Math.round(100 * (1 - speed / MAX_SPEED)));
  }

  /** Mission rating: 1-3 stars. */
  function stars(level, speed, beaconCount) {
    const fuel = fuelLeft(speed);
    const total = level.beacons.length;
    if (beaconCount === total && fuel >= level.fuelGoal) return 3;
    if (beaconCount >= Math.ceil(total / 2) || fuel >= level.fuelGoal) return 2;
    return 1;
  }

  const api = {
    DT, MAX_SPEED, MIN_LAUNCH_SPEED, PROBE_RADIUS, BEACON_RADIUS, BOUNDS,
    MAX_FLIGHT_TIME, KM_PER_UNIT, ASSIST_ZONE,
    bodyPos, accelAt, launchState, step, checkEvents, simulate, fuelLeft, stars, missionTime
  };

  root.LHPhysics = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
