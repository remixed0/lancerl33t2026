/*
 * Lagrange Hop 3D — synthesized sound effects (Web Audio API, no files)
 */
(function (root) {
  'use strict';

  function SoundFX() {
    this.ctx = null;
    this.enabled = true;
  }

  SoundFX.prototype.init = function () {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) this.ctx = new AC();
    }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  };

  SoundFX.prototype._tone = function (type, f0, f1, dur, vol, delay) {
    if (!this.enabled || !this.ctx) return;
    const now = this.ctx.currentTime + (delay || 0);
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, now);
    if (f1 !== f0) osc.frequency.exponentialRampToValueAtTime(f1, now + dur * 0.8);
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + dur);
  };

  SoundFX.prototype._noise = function (dur, f0, f1, vol) {
    if (!this.enabled || !this.ctx) return;
    const now = this.ctx.currentTime;
    const len = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(f0, now);
    filter.frequency.exponentialRampToValueAtTime(f1, now + dur);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    src.start(now);
  };

  SoundFX.prototype.launch = function () {
    this._noise(0.9, 1800, 120, 0.35);
    this._tone('sawtooth', 90, 320, 0.5, 0.12);
  };
  SoundFX.prototype.assist = function () {
    this._tone('sine', 300, 1100, 0.45, 0.16);
    this._tone('triangle', 450, 1500, 0.4, 0.08, 0.05);
  };
  SoundFX.prototype.beacon = function () {
    this._tone('triangle', 587.33, 587.33, 0.12, 0.18);
    this._tone('triangle', 880, 880, 0.3, 0.18, 0.08);
  };
  SoundFX.prototype.crash = function () {
    this._noise(0.6, 900, 60, 0.45);
  };
  SoundFX.prototype.lost = function () {
    this._tone('sine', 440, 110, 0.9, 0.12);
  };
  SoundFX.prototype.victory = function () {
    [440, 554.37, 659.25, 880].forEach((f, i) => this._tone('sine', f, f, 0.45, 0.18, i * 0.11));
  };
  SoundFX.prototype.click = function () {
    this._tone('square', 1200, 1200, 0.04, 0.04);
  };

  root.LHSound = SoundFX;
})(window);
