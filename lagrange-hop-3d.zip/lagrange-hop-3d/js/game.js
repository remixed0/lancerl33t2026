/*
 * Lagrange Hop 3D — game loop, input, rendering and HUD
 */
(function () {
  'use strict';

  const P = window.LHPhysics;
  const LEVELS = window.LHLevels;
  const E = window.LH3D;
  const { Planet } = window.LHPlanets;
  const sfx = new window.LHSound();

  const MAX_PULL = 16;               // drag distance (world units) for max speed
  const GRID = { x0: -62, x1: 62, z0: -42, z1: 42, step: 2, base: -3 };
  const SUN = E.v3.norm({ x: -0.75, y: 0.5, z: -0.35 });
  const CYAN = [56, 189, 248];
  const GREEN = [52, 211, 153];
  const GOLD = [250, 204, 21];
  const RED = [244, 63, 94];

  // ---------- DOM ----------
  const $ = (id) => document.getElementById(id);
  const canvas = $('scene');
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0, DPR = 1;
  let lastPortrait = null;

  // ---------- State ----------
  const cam = new E.Camera();
  let levelIndex = 0;
  let level = null;
  let planets = [];          // { body, planet }
  let hazardMeshes = [];
  let beaconMesh = null;
  const probeMesh = E.Mesh.probe();
  let stationMesh = null;
  let mode = 'AIM';          // AIM | FLY | END
  let tick = 0;
  let acc = 0;
  let warp = 1;
  let zoom = 1;
  let viewTop = false;
  let precise = false;
  const aim = { set: false, angle: 0, speed: 0 };
  let drag = null;           // { type: 'aim' | 'cam', x, y, point }
  const pointers = new Map();
  let pinchStart = null;
  let flight = null;
  let trail = [];
  let ghost = [];
  let prediction = null;
  let autopilot = null;      // { launchTick }
  let particles = [];
  let endTimer = 0;
  let lastAssistShown = null;
  let toastTimer = 0;
  let frame = 0;
  let best = loadBest();
  const stars = makeStars(700);

  function simTime() { return tick * P.DT; }

  // ---------- Level setup ----------
  function loadLevel(i) {
    levelIndex = (i + LEVELS.length) % LEVELS.length;
    level = JSON.parse(JSON.stringify(LEVELS[levelIndex]));
    planets = [level.earth].concat(level.bodies).map((b) => ({
      body: b,
      planet: new Planet(b.texture, b.name === 'Jupiter' ? 0.35 : 0.18, b.name === 'Earth' ? 0.41 : 0.15)
    }));
    hazardMeshes = level.hazards.map((h, k) => E.Mesh.asteroid(h.radius, k + 3 + levelIndex * 7));
    beaconMesh = E.Mesh.crystal(0.55, GOLD);
    stationMesh = E.Mesh.station(GREEN);
    $('levelTitle').textContent = level.title;
    document.querySelectorAll('.lvl-btn').forEach((b, k) => b.classList.toggle('active', k === levelIndex));
    ghost = [];
    cancelAutopilot();
    aim.set = false;
    resetProbe();
    setHint(level.hint);
    $('victoryModal').classList.add('hidden');
    fitCamera();
  }

  function resetProbe() {
    mode = 'AIM';
    flight = null;
    if (trail.length > 1) ghost = trail;
    trail = [];
    endTimer = 0;
    lastAssistShown = null;
    level.beacons.forEach((b) => { b.collected = false; });
    updateHud(true);
  }

  // ---------- Camera ----------
  // Phones in portrait: turn the board so it runs bottom (Earth) to top (target).
  function isPortrait() { return W / H < 0.9; }

  function fitDist() {
    return (isPortrait() ? cam.fitDistance(32, 52) : cam.fitDistance(50, 34)) * zoom;
  }

  function fitCamera() {
    const portrait = isPortrait();
    cam.goal.pitch = viewTop ? 1.53 : portrait ? 1.08 : 0.82;
    cam.goal.yaw = portrait ? -Math.PI / 2 : 0;
    cam.goal.tx = portrait && !viewTop ? -7 : 0;
    cam.goal.tz = portrait || viewTop ? 0 : 3;
    cam.goal.dist = fitDist();
  }

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = Math.round(W * DPR);
    canvas.height = Math.round(H * DPR);
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    const wasPortrait = lastPortrait;
    cam.setViewport(W, H);
    lastPortrait = isPortrait();
    if (level) {
      if (wasPortrait !== lastPortrait) fitCamera();
      else cam.goal.dist = fitDist();
    }
  }

  // ---------- Launch / autopilot ----------
  function launch(atTick) {
    if (mode !== 'AIM' || !aim.set || aim.speed < P.MIN_LAUNCH_SPEED) return;
    sfx.init();
    const t0 = (atTick === undefined ? tick : atTick) * P.DT;
    flight = P.launchState(level, aim.angle, aim.speed, t0);
    mode = 'FLY';
    if (trail.length > 1) ghost = trail;
    trail = [{ x: flight.x, z: flight.z }];
    lastAssistShown = null;
    sfx.launch();
    burst(flight.x, 0, flight.z, -flight.vx * 0.15, -flight.vz * 0.15, CYAN, 26, 1.2);
    setHint('Probe in flight. Watch the gravity wells bend its path.');
    $('launchBtn').classList.remove('pulse');
  }

  function orbitPeriod() {
    const ps = level.bodies.concat(level.hazards).filter((b) => b.orbit).map((b) => b.orbit.period);
    return ps.length ? Math.max(...ps) : 0;
  }

  function startAutopilot() {
    if (mode !== 'AIM') resetProbe();
    const ap = level.autopilot;
    aim.set = true;
    aim.angle = ap.deg * Math.PI / 180;
    aim.speed = ap.speed;
    const period = orbitPeriod();
    let launchTick = tick + 30;
    if (period) {
      const pt = Math.round(period / P.DT);
      const want = ((Math.round(ap.t0 / P.DT) % pt) + pt) % pt;
      const now = tick + 30;
      launchTick = now + ((want - (now % pt)) + pt) % pt;
    }
    autopilot = { launchTick };
    $('autoBtn').classList.add('active');
    sfx.init();
    sfx.click();
  }

  function cancelAutopilot() {
    autopilot = null;
    $('autoBtn').classList.remove('active');
  }

  // ---------- Physics tick ----------
  function physicsTick() {
    tick++;
    if (mode === 'AIM' && autopilot && tick >= autopilot.launchTick) {
      const at = autopilot.launchTick;
      cancelAutopilot();
      launch(at);
      return;
    }
    if (mode !== 'FLY') return;
    P.step(level, flight);
    const ev = P.checkEvents(level, flight);
    if (tick % 2 === 0) {
      trail.push({ x: flight.x, z: flight.z });
      if (trail.length > 1600) trail.shift();
    }
    ev.beacons.forEach((i) => {
      level.beacons[i].collected = true;
      const b = level.beacons[i];
      sfx.beacon();
      burst(b.x, 0.4, b.z, 0, 0, GOLD, 30, 1.6);
      toast('Science beacon ' + (i + 1) + ' collected');
    });
    if (flight.lastAssist && flight.lastAssist !== lastAssistShown) {
      lastAssistShown = flight.lastAssist;
      const gain = Math.round((flight.lastAssist.ratio - 1) * 100);
      if (gain >= 5) {
        sfx.assist();
        toast('GRAVITY ASSIST  +' + gain + '% speed from ' + flight.lastAssist.body, true);
        burst(flight.x, 0, flight.z, flight.vx * 0.1, flight.vz * 0.1, [168, 85, 247], 30, 1.4);
      }
    }
    if (ev.end) endFlight(ev.end);
  }

  function endFlight(end) {
    mode = 'END';
    if (end.type === 'capture') {
      sfx.victory();
      burst(level.target.x, 0, level.target.z, 0, 0, GREEN, 60, 2.2);
      showVictory();
      return;
    }
    if (end.type === 'crash') {
      sfx.crash();
      burst(flight.x, 0, flight.z, 0, 0, [249, 115, 22], 70, 2.6);
    } else {
      sfx.lost();
    }
    setHint((end.type === 'crash' ? 'IMPACT. ' : 'PROBE LOST. ') + end.reason + ' Resetting...');
    endTimer = 2.2;
  }

  // ---------- Prediction ----------
  function updatePrediction() {
    if (mode !== 'AIM' || !aim.set || aim.speed < P.MIN_LAUNCH_SPEED) {
      prediction = null;
      return;
    }
    const t0 = autopilot ? autopilot.launchTick * P.DT : simTime();
    const r = P.simulate(level, aim.angle, aim.speed, t0, { every: 3, maxTime: level.predictTime });
    prediction = r;
  }

  // ---------- Particles ----------
  function burst(x, y, z, bvx, bvz, color, n, speed) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const e = (Math.random() - 0.3) * 1.2;
      const sp = (0.4 + Math.random()) * speed * 6;
      particles.push({
        x, y, z,
        vx: Math.cos(a) * sp + bvx, vy: e * sp * 0.6, vz: Math.sin(a) * sp + bvz,
        life: 1, decay: 0.6 + Math.random() * 0.9, color, size: 0.25 + Math.random() * 0.35
      });
    }
  }

  function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      p.vx *= 0.97; p.vy *= 0.97; p.vz *= 0.97;
      p.life -= p.decay * dt;
      if (p.life <= 0) particles.splice(i, 1);
    }
    if (mode === 'FLY' && Math.random() < 0.6) {
      const sp = Math.hypot(flight.vx, flight.vz) || 1;
      particles.push({
        x: flight.x - flight.vx / sp * 0.7, y: 0, z: flight.z - flight.vz / sp * 0.7,
        vx: -flight.vx * 0.12 + (Math.random() - 0.5), vy: (Math.random() - 0.5) * 0.5,
        vz: -flight.vz * 0.12 + (Math.random() - 0.5),
        life: 0.7, decay: 1.6, color: [255, 160, 70], size: 0.22
      });
    }
  }

  // ---------- Rendering ----------
  function makeStars(n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const u = Math.random() * 2 - 1;
      const t = Math.random() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      out.push({
        d: { x: s * Math.cos(t), y: u, z: s * Math.sin(t) },
        m: Math.random() ** 3 * 1.6 + 0.35,
        tw: Math.random() * Math.PI * 2,
        c: Math.random() < 0.15 ? [255, 210, 170] : Math.random() < 0.3 ? [170, 200, 255] : [255, 255, 255]
      });
    }
    return out;
  }

  function drawBackground(time) {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#02040b');
    g.addColorStop(1, '#060b1a');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // Nebula haze (fixed to the sky, so it turns with the camera)
    ctx.globalCompositeOperation = 'lighter';
    const neb = [
      { d: E.v3.norm({ x: 0.6, y: 0.25, z: -0.8 }), c: [90, 40, 160], s: 0.9 },
      { d: E.v3.norm({ x: -0.3, y: 0.15, z: -0.9 }), c: [20, 90, 150], s: 0.7 },
      { d: E.v3.norm({ x: 0.9, y: 0.1, z: 0.4 }), c: [150, 50, 90], s: 0.6 }
    ];
    neb.forEach((n) => {
      const p = cam.project(E.v3.add(cam.pos, E.v3.scale(n.d, 500)));
      if (!p) return;
      const r = Math.max(W, H) * n.s;
      const gr = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
      gr.addColorStop(0, `rgba(${n.c[0]},${n.c[1]},${n.c[2]},0.13)`);
      gr.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gr;
      ctx.fillRect(p.x - r, p.y - r, r * 2, r * 2);
    });

    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      const p = cam.project(E.v3.add(cam.pos, E.v3.scale(s.d, 500)));
      if (!p || p.x < -2 || p.y < -2 || p.x > W + 2 || p.y > H + 2) continue;
      const a = 0.55 + Math.sin(time * 1.3 + s.tw) * 0.3;
      ctx.fillStyle = `rgba(${s.c[0]},${s.c[1]},${s.c[2]},${a})`;
      ctx.fillRect(p.x, p.y, s.m, s.m);
    }

    // The Sun, far away in the light direction
    const sp = cam.project(E.v3.add(cam.pos, E.v3.scale(SUN, 400)));
    if (sp) {
      const r = Math.min(W, H) * 0.28;
      ctx.drawImage(E.glow(255, 214, 150), sp.x - r, sp.y - r, r * 2, r * 2);
      ctx.drawImage(E.glow(255, 250, 235), sp.x - r * 0.18, sp.y - r * 0.18, r * 0.36, r * 0.36);
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  // Spacetime fabric: a grid that sinks under every mass.
  function wellDepth(x, z, t) {
    let phi = 0;
    const list = [level.earth].concat(level.bodies);
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      const p = P.bodyPos(b, t);
      const dx = x - p.x, dz = z - p.z;
      const s = b.radius * 1.7;
      phi += b.mass / Math.sqrt(dx * dx + dz * dz + s * s);
    }
    return 5.4 * Math.log(1 + phi / 6);
  }

  function drawGrid(t) {
    const nx = Math.round((GRID.x1 - GRID.x0) / GRID.step) + 1;
    const nz = Math.round((GRID.z1 - GRID.z0) / GRID.step) + 1;
    const pts = new Array(nx * nz);
    const dep = new Float32Array(nx * nz);
    for (let j = 0; j < nz; j++) {
      const z = GRID.z0 + j * GRID.step;
      for (let i = 0; i < nx; i++) {
        const x = GRID.x0 + i * GRID.step;
        const d = wellDepth(x, z, t);
        dep[j * nx + i] = d;
        pts[j * nx + i] = cam.project({ x, y: GRID.base - d, z });
      }
    }
    const BUCKETS = 6;
    const paths = [];
    for (let b = 0; b < BUCKETS; b++) paths.push(new Path2D());
    const add = (a, b, i0, j0) => {
      const pa = pts[a], pb = pts[b];
      if (!pa || !pb) return;
      const d = (dep[a] + dep[b]) * 0.5;
      // fade toward the edges of the grid
      const ex = Math.abs((GRID.x0 + i0 * GRID.step) / GRID.x1);
      const ez = Math.abs((GRID.z0 + j0 * GRID.step) / GRID.z1);
      const edge = Math.max(0, 1 - Math.max(ex, ez) ** 4);
      const v = Math.min(1, (0.22 + d * 0.1)) * edge;
      const k = Math.min(BUCKETS - 1, Math.floor(v * BUCKETS));
      paths[k].moveTo(pa.x, pa.y);
      paths[k].lineTo(pb.x, pb.y);
    };
    for (let j = 0; j < nz; j++) {
      for (let i = 0; i < nx; i++) {
        const a = j * nx + i;
        if (i + 1 < nx) add(a, a + 1, i, j);
        if (j + 1 < nz) add(a, a + nx, i, j);
      }
    }
    ctx.lineWidth = 1;
    for (let k = 0; k < BUCKETS; k++) {
      const a = 0.04 + (k / (BUCKETS - 1)) * 0.42;
      ctx.strokeStyle = `rgba(${CYAN[0]},${CYAN[1]},${CYAN[2]},${a})`;
      ctx.stroke(paths[k]);
    }
  }

  function circle3D(cx, cz, r, y, segs) {
    const out = [];
    for (let i = 0; i <= segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      out.push(cam.project({ x: cx + Math.cos(a) * r, y: y || 0, z: cz + Math.sin(a) * r }));
    }
    return out;
  }

  function strokePoly(pts, style, width, dash, offset) {
    ctx.beginPath();
    let pen = false;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i];
      if (!p) { pen = false; continue; }
      if (!pen) { ctx.moveTo(p.x, p.y); pen = true; } else ctx.lineTo(p.x, p.y);
    }
    ctx.strokeStyle = style;
    ctx.lineWidth = width;
    ctx.setLineDash(dash || []);
    ctx.lineDashOffset = offset || 0;
    ctx.stroke();
    ctx.setLineDash([]);
  }

  function fillPoly(pts, style) {
    ctx.beginPath();
    let first = true;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i];
      if (!p) continue;
      if (first) { ctx.moveTo(p.x, p.y); first = false; } else ctx.lineTo(p.x, p.y);
    }
    ctx.closePath();
    ctx.fillStyle = style;
    ctx.fill();
  }

  function drawPlaneMarks(t, time) {
    // Orbit paths
    level.bodies.concat(level.hazards).forEach((b) => {
      if (!b.orbit) return;
      strokePoly(circle3D(b.orbit.cx, b.orbit.cz, b.orbit.r, 0, 96), 'rgba(255,255,255,0.16)', 1, [3, 6]);
    });

    // Hazard danger zones
    level.hazards.forEach((h) => {
      const p = P.bodyPos(h, t);
      fillPoly(circle3D(p.x, p.z, h.radius + P.PROBE_RADIUS, 0, 28), 'rgba(244,63,94,0.10)');
      strokePoly(circle3D(p.x, p.z, h.radius + P.PROBE_RADIUS, 0, 28), 'rgba(244,63,94,0.35)', 1, [2, 4]);
    });

    // Target capture zone
    const tg = level.target;
    const pulse = 1 + Math.sin(time * 3) * 0.03;
    fillPoly(circle3D(tg.x, tg.z, tg.captureRadius * pulse, 0, 64), 'rgba(52,211,153,0.10)');
    strokePoly(circle3D(tg.x, tg.z, tg.captureRadius * pulse, 0, 64), 'rgba(52,211,153,0.9)', 1.8, [7, 6], -time * 20);
    strokePoly(circle3D(tg.x, tg.z, tg.captureRadius * 0.6, 0, 48), 'rgba(52,211,153,0.3)', 1, [2, 5], time * 14);

    // Beacon rings (highlight the ones the prediction will collect)
    level.beacons.forEach((b, i) => {
      if (b.collected) return;
      const hit = prediction && prediction.state.collected[i];
      strokePoly(circle3D(b.x, b.z, P.BEACON_RADIUS + P.PROBE_RADIUS, 0, 28),
        hit ? 'rgba(56,189,248,0.95)' : 'rgba(250,204,21,0.35)', hit ? 2 : 1, hit ? [] : [2, 4]);
    });
  }

  function drawPathPoints(points, style, width, dash) {
    strokePoly(points.map((p) => cam.project({ x: p.x, y: 0, z: p.z })), style, width, dash);
  }

  function drawTrails() {
    if (ghost.length > 1) drawPathPoints(ghost, 'rgba(148,163,184,0.28)', 1.2, [4, 5]);
    if (trail.length > 1) {
      // Draw the live trail in chunks that brighten toward the probe
      const n = trail.length;
      const chunk = 24;
      for (let s = 0; s < n - 1; s += chunk) {
        const part = trail.slice(s, Math.min(n, s + chunk + 1));
        const a = 0.15 + 0.85 * ((s + chunk) / n);
        drawPathPoints(part, `rgba(56,189,248,${Math.min(1, a)})`, 1 + a * 1.8);
      }
    }
  }

  function drawPrediction(time) {
    if (!prediction) return;
    const pts = prediction.points;
    ctx.globalCompositeOperation = 'lighter';
    const dotImg = E.glow(CYAN[0], CYAN[1], CYAN[2]);
    for (let i = 1; i < pts.length; i += 2) {
      const p = cam.project({ x: pts[i].x, y: 0, z: pts[i].z });
      if (!p) continue;
      const f = 1 - i / pts.length;
      const s = Math.max(2.5, p.scale * 0.55) * (0.6 + f * 0.6);
      ctx.globalAlpha = 0.25 + 0.75 * f;
      ctx.drawImage(dotImg, p.x - s, p.y - s, s * 2, s * 2);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';

    // Outcome marker at the end of the predicted path
    const last = pts[pts.length - 1];
    const p = cam.project({ x: last.x, y: 0, z: last.z });
    if (!p) return;
    const type = prediction.end.type;
    const r = Math.max(7, p.scale * 0.9);
    ctx.lineWidth = 2.5;
    if (type === 'capture') {
      ctx.strokeStyle = 'rgba(52,211,153,1)';
      ctx.beginPath(); ctx.arc(p.x, p.y, r * (1 + Math.sin(time * 6) * 0.15), 0, Math.PI * 2); ctx.stroke();
    } else if (type === 'crash') {
      ctx.strokeStyle = 'rgba(244,63,94,1)';
      ctx.beginPath();
      ctx.moveTo(p.x - r, p.y - r); ctx.lineTo(p.x + r, p.y + r);
      ctx.moveTo(p.x + r, p.y - r); ctx.lineTo(p.x - r, p.y + r);
      ctx.stroke();
    } else {
      ctx.fillStyle = 'rgba(148,163,184,0.9)';
      ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fill();
    }
  }

  function drawAim() {
    if (mode !== 'AIM' || !aim.set) return;
    const e = level.earth;
    const dx = Math.cos(aim.angle), dz = Math.sin(aim.angle);
    // Elastic cord while dragging
    if (drag && drag.type === 'aim' && drag.point) {
      strokePoly([cam.project({ x: e.x, y: 0, z: e.z }), cam.project(drag.point)], 'rgba(244,63,94,0.85)', 2.5);
      const dp = cam.project(drag.point);
      if (dp) { ctx.fillStyle = 'rgba(244,63,94,1)'; ctx.beginPath(); ctx.arc(dp.x, dp.y, 6, 0, Math.PI * 2); ctx.fill(); }
    }
    // Launch arrow, length shows power
    const len = e.radius + 1 + (aim.speed / P.MAX_SPEED) * 10;
    const tip = { x: e.x + dx * len, y: 0, z: e.z + dz * len };
    const a = cam.project({ x: e.x + dx * (e.radius + 0.6), y: 0, z: e.z + dz * (e.radius + 0.6) });
    const b = cam.project(tip);
    if (a && b) {
      strokePoly([a, b], 'rgba(56,189,248,0.95)', 3);
      const ang = Math.atan2(b.y - a.y, b.x - a.x);
      ctx.fillStyle = 'rgba(56,189,248,0.95)';
      ctx.beginPath();
      ctx.moveTo(b.x + Math.cos(ang) * 9, b.y + Math.sin(ang) * 9);
      ctx.lineTo(b.x + Math.cos(ang + 2.5) * 9, b.y + Math.sin(ang + 2.5) * 9);
      ctx.lineTo(b.x + Math.cos(ang - 2.5) * 9, b.y + Math.sin(ang - 2.5) * 9);
      ctx.fill();
    }
  }

  function drawObjects(t, time, dt) {
    const items = [];

    // Planets and moons (per-pixel rendered spheres)
    planets.forEach(({ body, planet }) => {
      const pos = P.bodyPos(body, t);
      const p = cam.project({ x: pos.x, y: 0, z: pos.z });
      if (!p) return;
      items.push({
        depth: p.depth,
        draw() {
          const pr = body.radius * p.scale;
          planet.render(pr, cam, SUN, dt);
          const k = pr / planet.drawRadius;
          const s = planet.size * k;
          ctx.drawImage(planet.canvas, p.x - s / 2, p.y - s / 2, s, s);
          // Pole line down into its gravity well
          const bottom = cam.project({ x: pos.x, y: GRID.base - wellDepth(pos.x, pos.z, t), z: pos.z });
          if (bottom) strokePoly([{ x: p.x, y: p.y + pr }, bottom], 'rgba(56,189,248,0.25)', 1, [2, 3]);
          label(body.name, p.x, p.y + pr + 14, '#cbd5e1');
        }
      });
    });

    // Asteroids
    level.hazards.forEach((h, i) => {
      const pos = P.bodyPos(h, t);
      const p = cam.project({ x: pos.x, y: 0, z: pos.z });
      if (!p) return;
      items.push({
        depth: p.depth,
        draw() {
          const faces = [];
          E.collectFaces(hazardMeshes[i], { x: pos.x, y: 0, z: pos.z },
            { yaw: time * 0.3 + i, pitch: time * 0.21 + i * 2, roll: i }, 1, cam, SUN, faces);
          E.drawFaces(ctx, faces);
          label(h.name, p.x, p.y + h.radius * p.scale + 12, '#a8a29e', 10);
        }
      });
    });

    // Science beacons
    level.beacons.forEach((b, i) => {
      if (b.collected) return;
      const y = 0.5 + Math.sin(time * 2 + i) * 0.25;
      const p = cam.project({ x: b.x, y, z: b.z });
      if (!p) return;
      items.push({
        depth: p.depth,
        draw() {
          ctx.globalCompositeOperation = 'lighter';
          const g = p.scale * 2.4;
          ctx.drawImage(E.glow(GOLD[0], GOLD[1], GOLD[2]), p.x - g, p.y - g, g * 2, g * 2);
          ctx.globalCompositeOperation = 'source-over';
          const faces = [];
          E.collectFaces(beaconMesh, { x: b.x, y, z: b.z }, { yaw: time * 1.6 + i }, 1, cam, SUN, faces);
          E.drawFaces(ctx, faces);
          label('BEACON ' + (i + 1), p.x, p.y - p.scale * 1.2 - 6, '#fde047', 10);
        }
      });
    });

    // Target station
    const tg = level.target;
    if (tg.kind === 'station') {
      const p = cam.project({ x: tg.x, y: 0, z: tg.z });
      if (p) {
        items.push({
          depth: p.depth,
          draw() {
            ctx.globalCompositeOperation = 'lighter';
            const g = p.scale * 3;
            ctx.drawImage(E.glow(GREEN[0], GREEN[1], GREEN[2]), p.x - g, p.y - g, g * 2, g * 2);
            ctx.globalCompositeOperation = 'source-over';
            const faces = [];
            E.collectFaces(stationMesh, { x: tg.x, y: 0, z: tg.z }, { yaw: time * 0.5, roll: 0.3 }, 1, cam, SUN, faces);
            E.drawFaces(ctx, faces);
          }
        });
      }
    }
    const tl = cam.project({ x: tg.x, y: 0, z: tg.z - tg.captureRadius });
    if (tl) items.push({ depth: -1, draw() { label(tg.name.toUpperCase(), tl.x, tl.y - 10, '#6ee7b7', 11); } });

    // Probe
    let probePos = null, probeYaw = 0;
    if (mode === 'FLY') {
      probePos = { x: flight.x, y: 0, z: flight.z };
      probeYaw = -Math.atan2(flight.vz, flight.vx);
    } else if (mode === 'AIM' && aim.set) {
      const e = level.earth;
      probePos = { x: e.x + Math.cos(aim.angle) * (e.radius + 0.9), y: 0, z: e.z + Math.sin(aim.angle) * (e.radius + 0.9) };
      probeYaw = -aim.angle;
    }
    if (probePos) {
      const p = cam.project(probePos);
      if (p) {
        items.push({
          depth: p.depth - 0.01,
          draw() {
            ctx.globalCompositeOperation = 'lighter';
            const g = Math.max(10, p.scale * 1.6);
            ctx.drawImage(E.glow(CYAN[0], CYAN[1], CYAN[2]), p.x - g, p.y - g, g * 2, g * 2);
            ctx.globalCompositeOperation = 'source-over';
            const faces = [];
            const bank = mode === 'FLY' ? Math.sin(time * 2) * 0.25 : 0;
            E.collectFaces(probeMesh, probePos, { yaw: probeYaw, roll: bank }, 1.25, cam, SUN, faces);
            E.drawFaces(ctx, faces);
          }
        });
      }
    }

    // Far to near
    items.sort((a, b) => b.depth - a.depth);
    items.forEach((it) => it.draw());
  }

  function drawParticles() {
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < particles.length; i++) {
      const q = particles[i];
      const p = cam.project(q);
      if (!p) continue;
      const s = Math.max(1.5, q.size * p.scale * 2);
      ctx.globalAlpha = Math.max(0, q.life);
      ctx.drawImage(E.glow(q.color[0], q.color[1], q.color[2]), p.x - s, p.y - s, s * 2, s * 2);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }

  function label(text, x, y, color, size) {
    ctx.font = `${size || 11}px "Share Tech Mono", ui-monospace, monospace`;
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(2,6,23,0.75)';
    ctx.fillText(text, x + 1, y + 1);
    ctx.fillStyle = color;
    ctx.fillText(text, x, y);
  }

  function render(time, dt) {
    const t = simTime();
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    drawBackground(time);
    drawGrid(t);
    drawPlaneMarks(t, time);
    drawTrails();
    drawPrediction(time);
    drawAim();
    drawObjects(t, time, dt);
    drawParticles();
  }

  // ---------- HUD ----------
  function setHint(text) { $('hintText').textContent = text; }

  function toast(text, big) {
    const el = $('toast');
    el.textContent = text;
    el.classList.toggle('big', !!big);
    el.classList.add('show');
    toastTimer = big ? 2.4 : 1.6;
  }

  function updateHud(force) {
    if (!force && frame % 4 !== 0) return;
    const s = flight;
    const speed = mode === 'FLY' && s ? Math.hypot(s.vx, s.vz) : (aim.set ? aim.speed : 0);
    $('telemetrySpeed').textContent = (speed * P.KM_PER_UNIT).toFixed(1) + ' km/s';
    $('telemetryBoost').textContent = (s ? s.maxBoost : 1).toFixed(2) + 'x';
    const fuel = aim.set || s ? P.fuelLeft(s ? s.launchSpeed : aim.speed) : 100;
    $('fuelBar').style.width = fuel + '%';
    $('fuelVal').textContent = fuel + '%';
    const got = level.beacons.filter((b) => b.collected).length;
    $('telemetryTokens').textContent = got + ' / ' + level.beacons.length;
    const mt = P.missionTime(level);
    const left = mode === 'FLY' && s ? Math.max(0, mt - (s.t - s.t0)) : mt;
    $('telemetryClock').textContent = left.toFixed(1) + ' s';
    $('telemetryClock').classList.toggle('warn', left < 3);

    // Aim panel
    if (aim.set) {
      let deg = (aim.angle * 180 / Math.PI) % 360;
      if (deg < 0) deg += 360;
      $('aimAngle').textContent = deg.toFixed(1) + '°';
      $('aimSpeed').textContent = (aim.speed * P.KM_PER_UNIT).toFixed(2) + ' km/s';
      $('aimFuel').textContent = P.fuelLeft(aim.speed) + '%';
    } else {
      $('aimAngle').textContent = '—';
      $('aimSpeed').textContent = '—';
      $('aimFuel').textContent = '—';
    }
    const pt = $('predictText');
    if (mode === 'FLY') {
      pt.textContent = 'In flight';
      pt.className = 'predict';
    } else if (autopilot) {
      const wait = Math.max(0, (autopilot.launchTick - tick) * P.DT);
      pt.textContent = 'AUTOPILOT: launch window in ' + wait.toFixed(1) + ' s';
      pt.className = 'predict auto';
    } else if (prediction) {
      const e = prediction.end;
      const n = prediction.beaconCount;
      if (e.type === 'capture') {
        const st = P.stars(level, aim.speed, n);
        pt.textContent = 'PREDICTED: CAPTURE · ' + n + '/' + level.beacons.length + ' beacons · ' + '★'.repeat(st) + '☆'.repeat(3 - st);
        pt.className = 'predict good';
      } else if (e.type === 'crash') {
        pt.textContent = 'PREDICTED: ' + e.reason.replace('.', '').toUpperCase();
        pt.className = 'predict bad';
      } else {
        pt.textContent = 'PREDICTED: MISSES TARGET';
        pt.className = 'predict';
      }
    } else {
      pt.textContent = 'Drag from Earth to aim';
      pt.className = 'predict';
    }
    $('launchBtn').disabled = !(mode === 'AIM' && aim.set && aim.speed >= P.MIN_LAUNCH_SPEED);
    $('launchBtn').classList.toggle('pulse', !$('launchBtn').disabled && precise);
  }

  function showVictory() {
    const s = flight;
    const n = level.beacons.filter((b) => b.collected).length;
    const st = P.stars(level, s.launchSpeed, n);
    $('metricTime').textContent = (s.t - s.t0).toFixed(1) + ' s';
    $('metricFuel').textContent = P.fuelLeft(s.launchSpeed) + '% left (3★ needs ' + level.fuelGoal + '%)';
    $('metricBoost').textContent = s.maxBoost.toFixed(2) + 'x';
    $('metricBeacons').textContent = n + ' / ' + level.beacons.length;
    $('starContainer').innerHTML = [0, 1, 2].map((k) => `<span class="${k < st ? 'on' : 'off'}">★</span>`).join('');
    $('victoryDesc').textContent = 'Orbit achieved at ' + level.target.name + '.';
    if (st > (best[levelIndex] || 0)) {
      best[levelIndex] = st;
      saveBest();
    }
    renderBest();
    setTimeout(() => $('victoryModal').classList.remove('hidden'), 700);
    setHint('Mission complete!');
  }

  function loadBest() {
    try { return JSON.parse(localStorage.getItem('lagrangeHop3dBest') || '{}'); } catch (e) { return {}; }
  }
  function saveBest() {
    try { localStorage.setItem('lagrangeHop3dBest', JSON.stringify(best)); } catch (e) { /* storage off */ }
  }
  function renderBest() {
    document.querySelectorAll('.lvl-btn').forEach((b, k) => {
      const n = best[k] || 0;
      b.querySelector('.lvl-stars').textContent = n ? '★'.repeat(n) : '';
    });
  }

  // ---------- Input ----------
  function setAimFromPoint(pt) {
    const e = level.earth;
    const px = e.x - pt.x, pz = e.z - pt.z;
    const len = Math.hypot(px, pz);
    if (len < 0.8) { aim.set = false; return; }
    aim.set = true;
    aim.angle = Math.atan2(pz, px);
    aim.speed = Math.min(1, len / MAX_PULL) * P.MAX_SPEED;
  }

  canvas.addEventListener('pointerdown', (ev) => {
    sfx.init();
    canvas.setPointerCapture(ev.pointerId);
    pointers.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    if (pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      pinchStart = { d: Math.hypot(a.x - b.x, a.y - b.y), zoom };
      drag = null;
      return;
    }
    const pt = cam.pickPlane(ev.clientX, ev.clientY);
    const e = level.earth;
    if (mode === 'AIM' && pt && Math.hypot(pt.x - e.x, pt.z - e.z) < e.radius + 4.5) {
      cancelAutopilot();
      drag = { type: 'aim', point: pt };
      setAimFromPoint(pt);
    } else {
      drag = { type: 'cam', x: ev.clientX, y: ev.clientY };
    }
  });

  canvas.addEventListener('pointermove', (ev) => {
    if (pointers.has(ev.pointerId)) pointers.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    if (pinchStart && pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      zoom = Math.max(0.45, Math.min(1.8, pinchStart.zoom * pinchStart.d / Math.max(d, 1)));
      cam.goal.dist = fitDist();
      return;
    }
    if (!drag) return;
    if (drag.type === 'aim') {
      const pt = cam.pickPlane(ev.clientX, ev.clientY);
      if (pt) { drag.point = pt; setAimFromPoint(pt); }
    } else {
      const dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
      drag.x = ev.clientX; drag.y = ev.clientY;
      cam.goal.yaw -= dx * 0.005;
      cam.goal.pitch = Math.max(0.22, Math.min(1.53, cam.goal.pitch + dy * 0.004));
      viewTop = cam.goal.pitch > 1.4;
      $('viewBtn').textContent = viewTop ? 'TOP VIEW' : '3D VIEW';
    }
  });

  function endPointer(ev) {
    pointers.delete(ev.pointerId);
    if (pointers.size < 2) pinchStart = null;
    if (drag && drag.type === 'aim') {
      drag = null;
      if (!precise) launch();
    } else {
      drag = null;
    }
  }
  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', endPointer);

  canvas.addEventListener('wheel', (ev) => {
    ev.preventDefault();
    zoom = Math.max(0.45, Math.min(1.8, zoom * Math.exp(ev.deltaY * 0.001)));
    cam.goal.dist = fitDist();
  }, { passive: false });

  window.addEventListener('keydown', (ev) => {
    if (ev.target.tagName === 'INPUT') return;
    const k = ev.key;
    const fine = ev.shiftKey ? 4 : 1;
    if (k === ' ' || k === 'Enter') { ev.preventDefault(); launch(); }
    else if (k === 'ArrowLeft' && aim.set && mode === 'AIM') { aim.angle -= 0.1 * fine * Math.PI / 180; cancelAutopilot(); ev.preventDefault(); }
    else if (k === 'ArrowRight' && aim.set && mode === 'AIM') { aim.angle += 0.1 * fine * Math.PI / 180; cancelAutopilot(); ev.preventDefault(); }
    else if (k === 'ArrowUp' && aim.set && mode === 'AIM') { aim.speed = Math.min(P.MAX_SPEED, aim.speed + 0.05 * fine); cancelAutopilot(); ev.preventDefault(); }
    else if (k === 'ArrowDown' && aim.set && mode === 'AIM') { aim.speed = Math.max(0, aim.speed - 0.05 * fine); cancelAutopilot(); ev.preventDefault(); }
    else if (k === 'r' || k === 'R') { cancelAutopilot(); resetProbe(); setHint(level.hint); }
    else if (k === 'a' || k === 'A') { autopilot ? cancelAutopilot() : startAutopilot(); }
    else if (k === 'v' || k === 'V') toggleView();
    else if (k === 'w' || k === 'W') toggleWarp();
    else if (k === 'p' || k === 'P') togglePrecise();
    else if (k === 'm' || k === 'M') toggleSound();
    else if (k >= '1' && k <= '3') loadLevel(Number(k) - 1);
    else if (k === 'Escape') { $('manualModal').classList.add('hidden'); }
  });

  // ---------- Buttons ----------
  function toggleView() {
    viewTop = !viewTop;
    $('viewBtn').textContent = viewTop ? 'TOP VIEW' : '3D VIEW';
    fitCamera();
  }
  function toggleWarp() {
    warp = warp === 1 ? 2 : warp === 2 ? 4 : 1;
    $('warpBtn').textContent = 'WARP ' + warp + 'x';
  }
  function togglePrecise() {
    precise = !precise;
    $('preciseBtn').textContent = precise ? 'AIM: PRECISE' : 'AIM: QUICK';
    $('preciseBtn').classList.toggle('active', precise);
    setHint(precise
      ? 'Precise aim: drag to set, arrow keys to fine-tune, then press LAUNCH (Space).'
      : level.hint);
  }
  function toggleSound() {
    sfx.init();
    sfx.enabled = !sfx.enabled;
    $('audioLabel').textContent = sfx.enabled ? 'SFX ON' : 'SFX OFF';
  }

  $('viewBtn').addEventListener('click', toggleView);
  $('warpBtn').addEventListener('click', toggleWarp);
  $('preciseBtn').addEventListener('click', togglePrecise);
  $('btnAudioToggle').addEventListener('click', toggleSound);
  $('launchBtn').addEventListener('click', () => launch());
  $('autoBtn').addEventListener('click', () => (autopilot ? cancelAutopilot() : startAutopilot()));
  $('btnReset').addEventListener('click', () => { cancelAutopilot(); resetProbe(); setHint(level.hint); });
  $('btnHelp').addEventListener('click', () => $('manualModal').classList.remove('hidden'));
  $('closeManualBtn').addEventListener('click', () => $('manualModal').classList.add('hidden'));
  $('startFromManualBtn').addEventListener('click', () => { sfx.init(); $('manualModal').classList.add('hidden'); });
  $('modalRetryBtn').addEventListener('click', () => { $('victoryModal').classList.add('hidden'); resetProbe(); setHint(level.hint); });
  $('modalNextBtn').addEventListener('click', () => loadLevel(levelIndex + 1));
  document.querySelectorAll('.lvl-btn').forEach((b) => {
    b.addEventListener('click', () => { sfx.init(); loadLevel(Number(b.dataset.level)); });
  });

  // ---------- Main loop ----------
  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    frame++;
    acc += dt * warp;
    let steps = 0;
    while (acc >= P.DT && steps < 40) {
      physicsTick();
      acc -= P.DT;
      steps++;
    }
    if (steps >= 40) acc = 0;

    if (mode === 'END' && endTimer > 0) {
      endTimer -= dt;
      if (endTimer <= 0) { resetProbe(); setHint(level.hint); }
    }
    if (toastTimer > 0) {
      toastTimer -= dt;
      if (toastTimer <= 0) $('toast').classList.remove('show');
    }

    cam.update(drag && drag.type === 'cam' ? 0.35 : 0.12);
    updatePrediction();
    updateParticles(dt);
    render(now / 1000, dt);
    updateHud();
    requestAnimationFrame(loop);
  }

  // ---------- Start ----------
  window.addEventListener('resize', resize);
  resize();
  renderBest();
  loadLevel(0);
  cam.update(1);
  requestAnimationFrame(loop);

  // Small hook for automated tests and the console
  window.LagrangeHop = {
    loadLevel, startAutopilot, launch,
    get mode() { return mode; },
    get flight() { return flight; },
    setWarp(n) { warp = n; }
  };
})();
