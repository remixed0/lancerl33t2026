/*
 * Lagrange Hop 3D — procedural planet textures + per-pixel sphere renderer
 *
 * No image files: every planet surface is generated from 3D noise when the
 * page loads. Each frame, each planet is ray-cast pixel by pixel into a small
 * offscreen canvas: the pixel's 3D surface normal is turned into a
 * latitude/longitude texture lookup and lit by the Sun. That gives real
 * rotating, sunlit planets with day and night sides.
 */
(function (root) {
  'use strict';

  const TEX_W = 256;
  const TEX_H = 128;

  // ---------- 3D value noise (seamless on a sphere) ----------
  function hash(x, y, z) {
    let h = (x * 374761393 + y * 668265263 + z * 2147483647) | 0;
    h = (h ^ (h >>> 13)) * 1274126177;
    h = h ^ (h >>> 16);
    return (h & 0xffff) / 0xffff;
  }
  function smooth(t) { return t * t * (3 - 2 * t); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function noise3(x, y, z) {
    const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
    const xf = smooth(x - xi), yf = smooth(y - yi), zf = smooth(z - zi);
    const c = (dx, dy, dz) => hash(xi + dx, yi + dy, zi + dz);
    return lerp(
      lerp(lerp(c(0, 0, 0), c(1, 0, 0), xf), lerp(c(0, 1, 0), c(1, 1, 0), xf), yf),
      lerp(lerp(c(0, 0, 1), c(1, 0, 1), xf), lerp(c(0, 1, 1), c(1, 1, 1), xf), yf),
      zf
    );
  }
  function fbm(x, y, z, oct) {
    let v = 0, amp = 0.5, f = 1, norm = 0;
    for (let i = 0; i < oct; i++) {
      v += noise3(x * f, y * f, z * f) * amp;
      norm += amp;
      amp *= 0.5;
      f *= 2.03;
    }
    return v / norm;
  }

  // ---------- Texture painters: (unit vector, lat) -> [r, g, b] ----------
  const painters = {
    earth(x, y, z, lat) {
      const n = fbm(x * 2.2 + 11, y * 2.2, z * 2.2, 5);
      const alat = Math.abs(lat);
      let c;
      if (alat > 1.22) c = [235, 242, 250];                     // ice caps
      else if (n > 0.53) {
        const t = Math.min(1, (n - 0.53) * 6);
        c = alat > 0.9 ? [150, 160, 140] : [lerp(64, 150, t), lerp(140, 120, t), lerp(60, 70, t)];
      } else {
        const d = Math.min(1, (0.53 - n) * 5);
        c = [lerp(40, 14, d), lerp(110, 50, d), lerp(190, 140, d)];  // ocean
      }
      const cloud = fbm(x * 3 + 40, y * 3, z * 3, 4);
      if (cloud > 0.56) {
        const a = Math.min(0.85, (cloud - 0.56) * 4);
        c = [lerp(c[0], 255, a), lerp(c[1], 255, a), lerp(c[2], 255, a)];
      }
      return c;
    },
    moon(x, y, z) {
      let v = 0.55 + (fbm(x * 3, y * 3, z * 3, 5) - 0.5) * 0.7;
      const maria = fbm(x * 1.3 + 5, y * 1.3, z * 1.3, 3);
      if (maria > 0.55) v -= 0.18;
      v += craters(x, y, z, 7) * 0.25;
      const g = Math.max(0, Math.min(1, v)) * 230;
      return [g, g, g * 1.02];
    },
    mars(x, y, z, lat) {
      const n = fbm(x * 2.5 + 3, y * 2.5, z * 2.5, 5);
      let c = [lerp(150, 220, n), lerp(60, 110, n), lerp(30, 60, n)];
      if (fbm(x * 1.5 + 9, y * 1.5, z * 1.5, 3) > 0.58) c = [c[0] * 0.65, c[1] * 0.6, c[2] * 0.6];
      if (Math.abs(lat) > 1.3) c = [240, 230, 225];
      return c;
    },
    jupiter(x, y, z, lat, lon) {
      const turb = fbm(x * 4, y * 4, z * 4, 4) - 0.5;
      const b = Math.sin(lat * 14 + turb * 3.2);
      const palette = b > 0.3 ? [232, 214, 180] : b > -0.3 ? [205, 160, 110] : [160, 105, 70];
      let c = palette.map((v) => v + turb * 40);
      // Great Red Spot
      const dl = (lat + 0.38) / 0.12;
      let dlon = lon - 1.2;
      dlon = Math.atan2(Math.sin(dlon), Math.cos(dlon)) / 0.3;
      const spot = dl * dl + dlon * dlon;
      if (spot < 1) {
        const t = 1 - spot;
        c = [lerp(c[0], 200, t), lerp(c[1], 85, t), lerp(c[2], 60, t)];
      }
      return c;
    },
    ganymede(x, y, z) {
      const n = fbm(x * 3 + 20, y * 3, z * 3, 5);
      let c = n > 0.5 ? [175, 165, 175] : [110, 100, 115];
      const k = craters(x, y, z, 5) * 40;
      return c.map((v) => v + k);
    },
    europa(x, y, z) {
      const n = fbm(x * 3 + 60, y * 3, z * 3, 4);
      const line = Math.abs(Math.sin((x * 7 + fbm(x * 6, y * 6, z * 6, 2) * 6)));
      const crack = line < 0.08 ? 0.6 : 1;
      return [ (220 + n * 30) * crack, (205 + n * 25) * crack * 0.95, (190 + n * 20) * crack * 0.85 ];
    }
  };

  function craters(x, y, z, scale) {
    // Cheap crater look: bright rims around dark bowls from cellular noise
    const n = noise3(x * scale + 100, y * scale, z * scale);
    if (n > 0.9) return -0.6;
    if (n > 0.86) return 0.4;
    return 0;
  }

  // ---------- Build equirectangular textures once ----------
  const textures = {};
  function buildTexture(name) {
    if (textures[name]) return textures[name];
    const paint = painters[name] || painters.moon;
    const data = new Uint8ClampedArray(TEX_W * TEX_H * 3);
    for (let j = 0; j < TEX_H; j++) {
      const lat = Math.PI / 2 - (j + 0.5) / TEX_H * Math.PI;
      const cl = Math.cos(lat);
      const y = Math.sin(lat);
      for (let i = 0; i < TEX_W; i++) {
        const lon = (i + 0.5) / TEX_W * Math.PI * 2 - Math.PI;
        const x = cl * Math.sin(lon);
        const z = cl * Math.cos(lon);
        const c = paint(x, y, z, lat, lon);
        const k = (j * TEX_W + i) * 3;
        data[k] = c[0]; data[k + 1] = c[1]; data[k + 2] = c[2];
      }
    }
    textures[name] = data;
    return data;
  }

  const ATMOSPHERE = {
    earth: [110, 180, 255],
    mars: [255, 160, 110],
    jupiter: [255, 210, 160],
    moon: null, ganymede: null, europa: [200, 220, 255]
  };

  /**
   * A renderable planet: keeps its own offscreen canvas and redraws itself.
   * cam must provide right/up/fwd unit vectors; sun is a unit vector.
   */
  function Planet(textureName, spinSpeed, tilt) {
    this.tex = buildTexture(textureName);
    this.name = textureName;
    this.atmo = ATMOSPHERE[textureName] || null;
    this.spin = Math.random() * Math.PI * 2;
    this.spinSpeed = spinSpeed;
    this.tilt = tilt || 0.3;
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d');
    this.size = 0;
    this.img = null;
  }

  Planet.prototype.render = function (pixelRadius, cam, sun, dt) {
    this.spin += this.spinSpeed * dt;
    // Draw at most ~120 px wide offscreen; the canvas scales it up smoothly.
    const r = Math.max(6, Math.min(60, Math.round(pixelRadius)));
    const pad = this.atmo ? Math.ceil(r * 0.25) + 2 : 2;
    const size = (r + pad) * 2;
    if (size !== this.size) {
      this.size = size;
      this.canvas.width = this.canvas.height = size;
      this.img = this.ctx.createImageData(size, size);
    }
    const out = this.img.data;
    out.fill(0);
    const R = cam.right, U = cam.up, F = cam.fwd;
    const cs = Math.cos(this.spin), sn = Math.sin(this.spin);
    const ct = Math.cos(this.tilt), st = Math.sin(this.tilt);
    const tex = this.tex;
    const atmo = this.atmo;
    const cx = size / 2;
    const rOuter = atmo ? r * 1.22 : r;

    for (let py = 0; py < size; py++) {
      const ny = -(py + 0.5 - cx) / r;
      for (let px = 0; px < size; px++) {
        const nx = (px + 0.5 - cx) / r;
        const d2 = nx * nx + ny * ny;
        const k = (py * size + px) * 4;
        if (d2 > 1) {
          // Atmospheric glow ring outside the disc
          if (atmo && d2 < (rOuter / r) * (rOuter / r)) {
            const d = Math.sqrt(d2);
            const a = (1 - (d - 1) / (rOuter / r - 1));
            // brighter on the lit side
            const wx = R.x * nx + U.x * ny, wy = R.y * nx + U.y * ny, wz = R.z * nx + U.z * ny;
            const lit = Math.max(0.15, (wx * sun.x + wy * sun.y + wz * sun.z) / d + 0.3);
            const alpha = a * a * 150 * Math.min(1, lit);
            out[k] = atmo[0]; out[k + 1] = atmo[1]; out[k + 2] = atmo[2]; out[k + 3] = alpha;
          }
          continue;
        }
        const nz = Math.sqrt(1 - d2);
        // World-space normal: screen right/up, toward the camera = -fwd
        let wx = R.x * nx + U.x * ny - F.x * nz;
        let wy = R.y * nx + U.y * ny - F.y * nz;
        let wz = R.z * nx + U.z * ny - F.z * nz;
        const light = wx * sun.x + wy * sun.y + wz * sun.z;
        // Into planet frame: undo axial tilt (about x), then spin (about y)
        const ty = wy * ct - wz * st;
        const tz = wy * st + wz * ct;
        const bx = wx * cs - tz * sn;
        const bz = wx * sn + tz * cs;
        const lat = Math.asin(Math.max(-1, Math.min(1, ty)));
        const lon = Math.atan2(bx, bz);
        const ti = Math.min(TEX_W - 1, ((lon + Math.PI) / (Math.PI * 2) * TEX_W) | 0);
        const tj = Math.min(TEX_H - 1, ((Math.PI / 2 - lat) / Math.PI * TEX_H) | 0);
        const t = (tj * TEX_W + ti) * 3;
        // Diffuse light with a soft terminator + faint night side
        let shade = Math.max(0, light);
        shade = 0.07 + 0.93 * Math.pow(shade, 0.8);
        let rr = tex[t] * shade, gg = tex[t + 1] * shade, bb = tex[t + 2] * shade;
        // Atmospheric rim tint
        if (atmo) {
          const rim = Math.pow(1 - nz, 3) * 0.8 * Math.max(0.2, light + 0.4);
          rr += (atmo[0] - rr) * rim; gg += (atmo[1] - gg) * rim; bb += (atmo[2] - bb) * rim;
        }
        // Smooth disc edge
        const edge = Math.min(1, (1 - Math.sqrt(d2)) * r * 1.5);
        out[k] = rr; out[k + 1] = gg; out[k + 2] = bb; out[k + 3] = 255 * edge;
      }
    }
    this.ctx.putImageData(this.img, 0, 0);
    this.drawRadius = r; // offscreen disc radius in px
  };

  root.LHPlanets = { Planet, buildTexture };
})(window);
